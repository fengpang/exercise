同步[../../README.md](../../README.md)的内容

将所有文档跟新到 www.kancloud.cn/wangfupeng/wangeditor3/332599 中
